import * as core from '../global';

// Validate members exposed through global
if (core.CognitoIdentityCredentials) {

} else if (core.Config) {

} else if (core.CredentialProviderChain) {

} else if (core.Credentials) {

} else if (core.EC2MetadataCredentials) {

} else if (core.RemoteCredentials) {

} else if (core.ECSCredentials) {

} else if (core.Endpoint) {

} else if (core.EnvironmentCredentials) {

} else if (core.EventListeners) {

} else if (core.FileSystemCredentials) {

} else if (core.HttpRequest) {

} else if (core.HttpResponse) {

} else if (core.MetadataService) {

} else if (core.Request) {
    
} else if (core.Response) {

} else if (core.SAMLCredentials) {
    
}